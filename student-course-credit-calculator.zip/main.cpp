#include <iostream>
#include <string>

using namespace std;

int main()
{
    string studentName;
    int numCourses;
    int pointsPerCourse;
    int extraCredit;
    int totalPoints;
    int finalScore;

    cout << "Enter your first name: ";
    cin >> studentName;

    cout << "How many courses are you taking? ";
    cin >> numCourses;

    cout << "How many points did you earn per course? ";
    cin >> pointsPerCourse;

    cout << "How many extra credit points do you have? ";
    cin >> extraCredit;

    // Calculate total points
    totalPoints = numCourses * pointsPerCourse;

    // Calculate final score with extra credit
    finalScore = totalPoints + extraCredit;

    // Display student name and final score
    cout << "Student: " << studentName << endl;
    cout << "Final score: " << finalScore << endl;

    return 0;
}